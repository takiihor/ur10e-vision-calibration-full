"""Guided local desktop UI; no robot or camera is opened until an action is chosen."""

import base64
import io
import json
import webbrowser
from datetime import datetime
from pathlib import Path

from . import __version__
from .dataset import load_result
from .ui_jobs import JobRunner
from .ui_layout import ScrollPage, flow_buttons
from .ui_preferences import load_camera_preference, preference_path, save_camera_preference


def session_name(prefix="cal"):
    return str(Path("sessions") / f"{prefix}-{datetime.now():%Y%m%d-%H%M%S-%f}")


def build_command(action, settings, *, calibration=None, verification=None):
    """Build an argument list, never a shell command. Refuse bad paths before connecting."""
    fixed = settings.get("calibration_type", "eye_in_hand") == "eye_to_hand"
    session = Path(settings["session"]).expanduser().resolve()
    offline = []
    metadata_path = session / "session.json"
    if action in ("solve", "intrinsics", "verify", "calibrate") and metadata_path.is_file():
        metadata = json.loads(metadata_path.read_text())
        recorded_manifest = metadata.get("board", {}).get("manifest")
        if recorded_manifest and not Path(recorded_manifest).is_file() and Path(settings["manifest"]).is_file():
            offline = ["--manifest", str(Path(settings["manifest"]).resolve())]
    intrinsic_path = settings.get("intrinsics", "").strip()
    if intrinsic_path and action in ("solve", "check", "plan", "collect"):
        from .intrinsics import load_intrinsics
        load_intrinsics(Path(intrinsic_path).expanduser())
    if action == "solve":
        command = ["solve", "--session", str(session), *offline]
        if intrinsic_path:
            command += ["--intrinsics", str(Path(intrinsic_path).expanduser().resolve())]
        if (session / "calibration.json").exists():
            command += ["--output", str(session / f"calibration-{datetime.now():%Y%m%d-%H%M%S-%f}.json")]
        return command
    if action == "intrinsics":
        return ["intrinsics", "--session", str(session), *offline,
                "--output", str(session / f"intrinsics-{datetime.now():%Y%m%d-%H%M%S-%f}.json")]
    if action == "calibrate":
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
        return ["calibrate", "--session", str(session), *offline,
                "--intrinsics-output", str(session / f"intrinsics-{stamp}.json"),
                "--output", str(session / f"calibration-rgb-{stamp}.json")]
    if action == "verify":
        if not calibration or not verification:
            raise ValueError("Load a calibration and choose a verification session first")
        verification = Path(verification).expanduser().resolve()
        if session == verification:
            raise ValueError("Choose fresh verification observations, separate from the calibration session")
        if not all((verification / name).is_file() for name in ("session.json", "samples.jsonl")):
            raise ValueError("Collect fresh verification views first; the chosen verification folder has no recording")
        output = verification / f"verification-{datetime.now():%Y%m%d-%H%M%S-%f}.json"
        return ["verify", "--calibration", str(calibration), "--session", str(verification), *offline,
                "--output", str(output)]
    if fixed and action == "replay":
        raise ValueError("Eye-to-hand verification uses manual Local Control capture in this UI; "
                         "remote replay is a separate CLI operation")
    if action == "simulate":
        if fixed:
            raise ValueError("The rendered simulation currently supports eye-in-hand only")
        output = session
        command = ["simulate", "--output", str(output)]
    else:
        if not settings["robot_ip"].strip():
            raise ValueError("Enter the robot IP address in Setup")
        manifest = Path(settings["manifest"]).expanduser().resolve()
        if not manifest.is_file():
            raise ValueError("Choose the generated calibration board_manifest.json in Setup")
        common = [
            "--robot-ip",
            settings["robot_ip"].strip(),
            "--manifest",
            str(manifest),
            "--board",
            settings["board"].strip(),
        ]
        if settings["serial"].strip():
            common += ["--serial", settings["serial"].strip()]
        if action in ("replay", "manual") and calibration:
            # A loaded hand-eye result contains the exact model used during solving.
            common += ["--intrinsics", str(calibration)]
        elif intrinsic_path:
            common += ["--intrinsics", str(Path(intrinsic_path).expanduser().resolve())]
        if action == "check":
            return ["check", *common, *(["--calibration-type", "eye_to_hand"] if fixed else [])]
        if action not in ("plan", "collect", "replay", "manual"):
            raise ValueError("Unknown UI action")
        from .poses import PlanOptions
        from .robot import MotionLimits

        speed, views = (0.1, 14) if fixed else (float(settings["speed"]), int(settings["views"]))
        MotionLimits(joint_speed_rad_s=speed)
        tilt, roll = float(settings.get('tilt_deg', 25)), float(settings.get('roll_deg', 30))
        PlanOptions(tilt_deg=tilt, roll_deg=roll, max_views=views)
        if views > 14:
            raise ValueError("Choose 6-14 calibration views")
        output = session
        if action == "plan":
            if fixed:
                raise ValueError("Eye-to-hand uses pendant-positioned manual capture; no automatic plan is needed")
            output = session.parent / (session.name + f"-plan-{datetime.now():%H%M%S-%f}")
        elif action in ("replay", "manual"):
            if not verification:
                raise ValueError("Choose a new verification session folder")
            output = Path(verification).expanduser().resolve()
        command = ["collect", *common, "--output", str(output), "--joint-speed", str(speed), "--views", str(views)]
        command += ['--tilt-deg', str(tilt), '--roll-deg', str(roll)]
        if settings.get('collision_scene', '').strip():
            from .collision import load_scene
            path = Path(settings['collision_scene']).expanduser().resolve()
            scene = load_scene(path)
            if action in ('collect', 'replay') and not fixed:
                scene.require_motion_ready()
            command += ['--collision-scene', str(path)]
        command += ["--calibration-type", "eye_to_hand" if fixed else "eye_in_hand"]
        if fixed and action == "collect":
            command += ["--mode", "manual"]
        if action == "plan":
            command += ["--dry-run"]
        elif action == "replay":
            command += ["--mode", "replay", "--replay", str(session)]
        elif action == "manual":
            command += ["--mode", "manual"]
    if output.exists() and (not output.is_dir() or any(output.iterdir())):
        raise ValueError(f"{output} already contains data. Choose a new session folder; existing data is preserved.")
    return command


class CalibrationUI:
    def __init__(self, root, *, preferences_path=None):
        import tkinter as tk
        from tkinter import ttk

        self.tk, self.ttk, self.root = tk, ttk, root
        self.preferences_path = Path(preferences_path) if preferences_path is not None else preference_path()
        self.runner = JobRunner()
        self.action = None
        self.verification_passed = False
        self.closing = False
        self.checked = self.planned = None
        self.result = self.result_path = None
        self.preview_photo = None
        self.preview_image = None
        self.preview_caption = "Position the camera so the whole\nboard is visible, then Check view."
        self.preview_canvases = []
        self.compact_layout = None
        self.last_workflow_tab = 0
        self.accepted = self.rejected = 0
        self.widgets = []
        self.step_lights = {}
        manifest, board = "", "calibration"
        self.settings = {
            key: tk.StringVar(value=value)
            for key, value in {
                "calibration_type": "eye_in_hand",
                "robot_ip": "",
                "manifest": manifest,
                "board": board,
                "serial": "",
                "intrinsics": load_camera_preference(self.preferences_path),
                "session": session_name(),
                "speed": "0.1",
                "views": "14",
                "tilt_deg": "25",
                "roll_deg": "30",
                "collision_scene": str(Path(__file__).parent / 'web/collision-scene.example.json'),
            }.items()
        }
        self.verification = tk.StringVar(value=session_name("check"))
        self.status = tk.StringVar(value="Ready · choose Setup to begin")
        self.sample_status = tk.StringVar(value="No captures yet")
        self.result_status = tk.StringVar(value="No calibration loaded")
        self.result_location = tk.StringVar()
        self.warnings = tk.StringVar(value="Solve a recorded session or run a simulation to see results.")
        self.pose = tk.StringVar(value="-")
        self.verify_status = tk.StringVar(value="Collect fresh views without changing the camera or board mounting.")
        self._layout()
        self.refresh_setup()
        for key, variable in self.settings.items():
            variable.trace_add("write", lambda *_, k=key: self.settings_changed(k))
        self.verification.trace_add("write", lambda *_: self.reset_steps("replay", "manual", "verify"))
        for variable in self.ready:
            variable.trace_add("write", lambda *_: self.update_setup_light())
        self.update_setup_light()
        root.report_callback_exception = self.callback_error
        root.protocol("WM_DELETE_WINDOW", self.close)
        root.after(80, self.poll)

    def _button(self, parent, text, command, *, step=None, **kwargs):
        container = self.ttk.Frame(parent) if step else parent
        button = self.ttk.Button(container, text=text, command=command, **kwargs)
        self.widgets.append(button)
        if step:
            button.pack(side="left")
            light = self.ttk.Label(container, font=("Helvetica", 10, "bold"))
            light.pack(side="left", padx=(10, 0))
            self.step_lights[step] = light
            self.set_step(step, "pending")
            return container
        return button

    def set_step(self, step, state):
        appearance = {
            "pending": ("● Pending", "#667085"),
            "running": ("● Running", "#946200"),
            "ready": ("● Ready", "#16803c"),
            "failed": ("● Failed", "#b42318"),
            "stopped": ("● Stopped", "#946200"),
            "review": ("● Review warnings", "#946200"),
        }
        if step == "collect":
            self.set_step("fixed_collect", state)
        if step in self.step_lights:
            text, colour = appearance[state]
            self.step_lights[step].configure(text=text, foreground=colour)

    def reset_steps(self, *steps):
        for step in steps:
            self.set_step(step, "pending")

    def update_setup_light(self):
        valid = (bool(self.settings["robot_ip"].get().strip())
                 and Path(self.settings["manifest"].get()).expanduser().is_file()
                 and bool(self.settings["board"].get().strip())
                 and all(v.get() for v in self.ready))
        self.set_step("setup", "ready" if valid else "pending")

    def settings_changed(self, key):
        if key != "session":
            self.checked = self.planned = None
            self.reset_steps("check", "plan", "collect", "replay", "manual", "verify")
        else:
            self.reset_steps("collect", "solve", "simulate", "replay", "manual", "verify")
            self.result = self.result_path = None
            self.result_status.set("No calibration loaded for this session")
        if key == "calibration_type":
            self.refresh_setup()
            for value in self.ready:
                value.set(False)
            self.result = self.result_path = None
            self.result_status.set("Setup changed · solve or open a matching calibration")
            self.metrics.delete(*self.metrics.get_children())
            self.pose.set("-")
            self.reset_steps("solve", "intrinsics", "simulate")
        if key == "intrinsics":
            save_camera_preference(self.preferences_path, self.settings["intrinsics"].get())
            self.reset_steps("solve", "intrinsics")
            self.result = self.result_path = None
            self.result_status.set("Camera model changed · solve the session again")
            self.metrics.delete(*self.metrics.get_children())
            self.pose.set("-")
            self.warnings.set("Solve the session with the selected RGB camera model.")
        self.update_setup_light()

    def _text(self, parent, text=None, **kwargs):
        label = self.ttk.Label(parent, text=text, wraplength=570, justify="left", **kwargs)

        def wrap(event):
            width = max(80, event.width - 32)
            if int(label.cget("wraplength")) != width:
                label.configure(wraplength=width)

        parent.bind("<Configure>", wrap, add="+")
        return label

    def _entry(self, parent, row, label, variable, browse=None):
        self.ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", padx=(0, 12), pady=5)
        entry = self.ttk.Entry(parent, textvariable=variable)
        entry.grid(row=row, column=1, sticky="ew", pady=5)
        self.widgets.append(entry)
        if browse:
            self._button(parent, "Browse...", browse).grid(row=row, column=2, padx=(6, 0), pady=5)

    def _layout(self):
        import tkinter.font as font

        tk, ttk, root = self.tk, self.ttk, self.root
        root.title(f"UR10e · Camera calibration · v{__version__}")
        width = max(720, min(1280, root.winfo_screenwidth() - 80))
        height = max(480, min(900, root.winfo_screenheight() - 120))
        root.geometry(f"{width}x{height}")
        root.minsize(720, 480)
        root.configure(background="#f3f5f8")
        style = ttk.Style(root)
        style.theme_use("clam")
        font.nametofont("TkDefaultFont").configure(family="Helvetica", size=10)
        font.nametofont("TkTextFont").configure(family="Helvetica", size=10)
        style.configure("TFrame", background="#f3f5f8")
        style.configure("TLabel", background="#f3f5f8", foreground="#203047", font=("Helvetica", 10))
        style.configure("Title.TLabel", font=("Helvetica", 20, "bold"))
        style.configure("Heading.TLabel", font=("Helvetica", 13, "bold"))
        style.configure("TButton", padding=(12, 8), font=("Helvetica", 10))
        style.configure("TNotebook", background="#f3f5f8", borderwidth=0)
        style.configure("TNotebook.Tab", padding=(12, 9), background="#e2e8f0", font=("Helvetica", 10))
        style.map("TNotebook.Tab", background=[("selected", "#ffffff")], foreground=[("selected", "#0f766e")])
        style.configure("TCheckbutton", background="#f3f5f8", font=("Helvetica", 10))
        style.configure("TLabelframe", background="#f3f5f8")
        style.configure("TLabelframe.Label", background="#f3f5f8", font=("Helvetica", 10))
        style.configure("Primary.TButton", background="#0f766e", foreground="white")
        style.map(
            "Primary.TButton",
            background=[("disabled", "#e2e8f0"), ("active", "#115e59")],
            foreground=[("disabled", "#6b7280")],
        )
        style.configure("Stop.TButton", foreground="#a12424", font=("Helvetica", 11, "bold"))
        root.columnconfigure(0, weight=1)
        root.rowconfigure(1, weight=1)
        header = ttk.Frame(root, padding=(16, 12))
        header.grid(row=0, column=0, sticky="ew")
        header.columnconfigure(0, weight=1)
        ttk.Label(header, text=f"Camera calibration · v{__version__}", style="Title.TLabel").grid(
            row=0, column=0, sticky="w"
        )
        ttk.Label(header, text="UR10e + RealSense  /  Guided hand-eye calibration").grid(row=1, column=0, sticky="w")
        self.stop_button = ttk.Button(
            header, text="Stop operation", style="Stop.TButton", command=self.stop, state="disabled"
        )
        self.stop_button.grid(row=0, column=1, rowspan=2)
        body = self.body = ttk.Frame(root, padding=(16, 0, 16, 8))
        body.grid(row=1, column=0, sticky="nsew")
        body.columnconfigure(0, weight=1)
        body.rowconfigure(0, weight=1)
        self.tabs = ttk.Notebook(body)
        self.tabs.grid(row=0, column=0, sticky="nsew", padx=(0, 18))
        self.pages = []
        self.scroll_pages = []
        for title in ("1 Setup", "2 Plan", "3 Capture", "4 Results", "5 Verify"):
            page = ScrollPage(self.tabs, tk, ttk)
            self.tabs.add(page.frame, text=title)
            self.scroll_pages.append(page)
            self.pages.append(page.content)
        self._setup_page()
        self._plan_page()
        self._capture_page()
        self._result_page()
        self._verify_page()
        self.wide_preview = self._preview_panel(body)
        self.compact_preview = self._preview_panel(self.tabs)
        self.tabs.bind("<<NotebookTabChanged>>", self._tab_changed)
        body.bind("<Configure>", self._adapt_width)
        self.prompt_frame = ttk.LabelFrame(root, text="Operator action required", padding=12)
        self.prompt_frame.grid(row=2, column=0, sticky="ew", padx=22, pady=8)
        self.prompt_frame.columnconfigure(0, weight=1)
        self.prompt_text = tk.Text(self.prompt_frame, width=1, height=4, wrap="word", font=("Courier", 9))
        self.prompt_text.grid(row=0, column=0, sticky="ew")
        prompt_scroll = ttk.Scrollbar(self.prompt_frame, command=self.prompt_text.yview)
        prompt_scroll.grid(row=0, column=1, sticky="ns")
        self.prompt_text.configure(yscrollcommand=prompt_scroll.set)
        self.prompt_buttons = ttk.Frame(self.prompt_frame)
        self.prompt_buttons.grid(row=1, column=0, sticky="ew", pady=(8, 0))
        self.prompt_frame.grid_remove()
        activity = ttk.Frame(root, padding=(16, 0, 16, 0))
        activity.grid(row=3, column=0, sticky="ew")
        activity.columnconfigure(0, weight=1)
        self.activity_visible = tk.BooleanVar(value=height >= 800)
        self.activity_toggle = ttk.Button(activity, command=self.toggle_activity)
        self.activity_toggle.grid(row=0, column=0, sticky="w", pady=3)
        log_frame = self.activity_frame = ttk.Frame(activity)
        log_frame.grid(row=1, column=0, sticky="ew")
        log_frame.columnconfigure(0, weight=1)
        log_frame.rowconfigure(0, weight=1)
        self.log = tk.Text(
            log_frame,
            width=1,
            height=4,
            state="disabled",
            wrap="word",
            font=("Courier", 9),
            background="#19273b",
            foreground="#e6edf6",
        )
        self.log.grid(row=0, column=0, sticky="nsew")
        scrollbar = ttk.Scrollbar(log_frame, command=self.log.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.log.configure(yscrollcommand=scrollbar.set)
        self._update_activity()
        self.status_label = ttk.Label(root, textvariable=self.status, padding=(16, 6), anchor="w")
        self.status_label.grid(row=4, column=0, sticky="ew")
        root.bind("<Configure>", self._status_width, add="+")

    def _status_width(self, event):
        if event.widget == self.root:
            self.status_label.configure(wraplength=max(80, event.width - 32))

    def _preview_panel(self, parent):
        panel = ScrollPage(parent, self.tk, self.ttk, padding=12)
        page = panel.content
        page.columnconfigure(0, weight=1)
        self._text(page, "Latest board image", style="Heading.TLabel").grid(row=0, column=0, sticky="w")
        self._text(page, "Updated after a check or capture. Green circles mark detected corners.").grid(
            row=1, column=0, sticky="w", pady=(6, 10))
        canvas = self.tk.Canvas(page, width=1, height=200, highlightthickness=0, background="#e1e7ef")
        canvas.create_text(0, 0, text=self.preview_caption, fill="#53647b", justify="center", tags="caption")
        canvas.create_image(0, 0, tags="image")
        canvas.grid(row=2, column=0, sticky="ew")
        canvas.viewport = panel.canvas
        canvas.bind("<Configure>", lambda event: self._draw_preview(event.widget))
        panel.canvas.bind("<Configure>", lambda event: canvas.after_idle(lambda: self._draw_preview(canvas)), add="+")
        self.preview_canvases.append(canvas)
        self._text(page, textvariable=self.sample_status).grid(row=3, column=0, sticky="w", pady=10)
        self._text(page, "Keep the board fixed and supervise motion with the physical emergency stop accessible. "
                   "Stop operation requests software interruption and cleanup.", foreground="#8b4c12").grid(
                       row=4, column=0, sticky="w", pady=8)
        return panel

    def _draw_preview(self, canvas):
        from PIL import ImageTk

        width = max(1, canvas.winfo_width())
        available_height = max(32, canvas.viewport.winfo_height() - canvas.winfo_y() - 12)
        height = max(32, min(300, round(width * 9 / 16), available_height))
        if int(canvas.cget("height")) != height:
            canvas.configure(height=height)
        canvas.coords("caption", width / 2, height / 2)
        canvas.itemconfigure("caption", text=self.preview_caption, width=max(1, width - 24),
                             state="hidden" if self.preview_image is not None else "normal")
        canvas.coords("image", width / 2, height / 2)
        if self.preview_image is None:
            canvas.itemconfigure("image", image="")
            canvas.photo = None
        else:
            picture = self.preview_image.copy()
            picture.thumbnail((max(1, width - 8), max(1, height - 8)))
            canvas.photo = ImageTk.PhotoImage(picture, master=canvas)
            canvas.itemconfigure("image", image=canvas.photo)
            self.preview_photo = canvas.photo

    def _tab_changed(self, event=None):
        selected = self.tabs.select()
        if selected and selected != str(self.compact_preview.frame):
            self.last_workflow_tab = self.tabs.index(selected)

    def _adapt_width(self, event):
        compact = event.width < 1100
        if compact == self.compact_layout:
            return
        self.compact_layout = compact
        if compact:
            self.wide_preview.frame.grid_remove()
            self.body.columnconfigure(1, minsize=0)
            self.tabs.grid_configure(columnspan=2, padx=0)
            self.tabs.add(self.compact_preview.frame, text="Live view")
        else:
            if str(self.compact_preview.frame) in self.tabs.tabs():
                if self.tabs.select() == str(self.compact_preview.frame):
                    self.tabs.select(self.last_workflow_tab)
                self.tabs.forget(self.compact_preview.frame)
            self.body.columnconfigure(1, minsize=380)
            self.tabs.grid_configure(columnspan=1, padx=(0, 14))
            self.wide_preview.frame.grid(row=0, column=1, sticky="nsew")

    def _update_activity(self):
        if self.activity_visible.get():
            self.activity_frame.grid()
            self.activity_toggle.configure(text="Hide Activity")
        else:
            self.activity_frame.grid_remove()
            self.activity_toggle.configure(text="Show Activity")

    def toggle_activity(self):
        self.activity_visible.set(not self.activity_visible.get())
        self._update_activity()

    def _setup_page(self):
        ttk, page = self.ttk, self.pages[0]
        self._text(page, "Start with one clear view", style="Heading.TLabel").pack(anchor="w")
        self._text(
            page, "Select the mounting arrangement, then set the first visible board pose using the pendant."
        ).pack(anchor="w", pady=(6, 12))
        for value, title, description in (
            ("eye_in_hand", "Eye in hand", "Camera on robot flange; calibration board stays fixed on the platform."),
            ("eye_to_hand", "Eye to hand",
             "Camera fixed on platform; calibration board rigidly attached to robot flange."),
        ):
            choice = ttk.Radiobutton(page, text=title, variable=self.settings["calibration_type"], value=value)
            choice.pack(anchor="w", pady=(6, 0))
            self.widgets.append(choice)
            self._text(page, description).pack(anchor="w", padx=24)
        form = ttk.Frame(page)
        form.pack(fill="x")
        form.columnconfigure(1, weight=1)
        for row, (key, label, browse) in enumerate(
            [
                ("robot_ip", "Robot IP", None),
                ("manifest", "Board manifest", self.browse_manifest),
                ("board", "Board name", None),
                ("serial", "Camera serial (optional)", None),
                ("intrinsics", "RGB intrinsics (optional)", self.browse_intrinsics),
                ("session", "Session folder", self.browse_session),
                ("collision_scene", "Collision scene JSON", self.browse_collision_scene),

            ]
        ):
            self._entry(form, row, label, self.settings[key], browse)
        self.motion_settings = ttk.Frame(form)
        self.motion_settings.grid(row=7, column=0, columnspan=3, sticky="ew")
        self.motion_settings.columnconfigure(1, weight=1)
        self._entry(self.motion_settings, 0, "Joint speed (rad/s)", self.settings["speed"])
        self._entry(self.motion_settings, 1, "Views (6-14)", self.settings["views"])
        self._entry(self.motion_settings, 2, "Tilt (5-40 deg)", self.settings['tilt_deg'])
        self._entry(self.motion_settings, 3, "Roll (0-60 deg)", self.settings['roll_deg'])
        self._text(page, 'The example collision scene blocks automatic motion. Export a measured scene from the tool box editor.').pack(anchor='w')
        self._text(page, "Leave RGB intrinsics empty to use the recorded or factory model. Select a camera "
                   "calibration JSON to correct lens distortion.").pack(anchor="w", pady=(3, 8))
        self._button(page, "Open tool box draft",
                     lambda: webbrowser.open((Path(__file__).parent / "web" / "tool-envelope.html").as_uri())).pack(
            anchor="w", pady=(0, 8)
        )
        self.control_preparation = self.tk.StringVar()
        self.ready = []
        for index, text in enumerate((
            "Camera and board rigidly mounted as selected; board flat and printed at 100% scale",
            "Robot in Remote Control; other RTDE control clients disconnected",
            "Initial pose set: whole board visible, roughly centred, 0.3-0.6 m away",
            "Entire motion area checked; emergency stop accessible",
        )):
            value = self.tk.BooleanVar(value=False)
            row = ttk.Frame(page)
            row.pack(fill="x", pady=4)
            row.columnconfigure(1, weight=1)
            box = ttk.Checkbutton(row, variable=value)
            box.grid(row=0, column=0, sticky="nw")
            label = (self._text(row, textvariable=self.control_preparation) if index == 1
                     else self._text(row, text))
            label.grid(row=0, column=1, sticky="w")
            label.bind("<Button-1>", lambda event, b=box: b.invoke() if not b.instate(["disabled"]) else None)
            self.widgets.append(box)
            self.ready.append(value)
        buttons = ttk.Frame(page)
        buttons.pack(fill="x", pady=(14, 0))
        self._button(buttons, "Continue to check >", lambda: self.tabs.select(1), step="setup").pack(side="left")
        self.simulate_button = self._button(buttons, "Try eye-in-hand simulation", self.simulate, step="simulate")
        self.simulate_button.pack(side="left", padx=8)
        flow_buttons(buttons)
        self._text(page, "Simulation uses no hardware. Live robot operation still needs physical validation.").pack(
            anchor="w", pady=10
        )

    def _plan_page(self):
        page = self.pages[1]
        self.check_heading = self.tk.StringVar(value="Check the view, then inspect the plan")
        self._text(page, textvariable=self.check_heading, style="Heading.TLabel").pack(anchor="w")
        self._text(
            page, "1. Check reads robot status and captures a board image. Adjust the first pose until the view passes."
        ).pack(anchor="w", pady=12)
        self._button(page, "Check view (read-only)", lambda: self.start("check"), step="check",
                     style="Primary.TButton").pack(anchor="w")
        self.auto_plan = self.ttk.Frame(page)
        self.auto_plan.pack(fill="x")
        page = self.auto_plan
        self._text(
            page, "2. Inspect a preliminary plan without moving. Review each flange pose and joint target in Activity."
        ).pack(anchor="w", pady=12)
        self._button(page, "Inspect plan (no motion)", lambda: self.start("plan"), step="plan").pack(anchor="w")
        self._text(
            page,
            "Planning opens RTDE control. It may stop a running robot program. "
            "The dry run assumes camera orientation. The live plan uses the measured orientation after probing. "
            "Collision checks cover each joint path and return. The checks use the selected model and scene.",
            foreground="#8b4c12",
        ).pack(anchor="w", pady=16)
        self.fixed_plan = self._text(self.pages[1], "Eye to hand: after Check view passes, continue to Capture. "
                                    "Jog the flange-mounted board using the pendant; no automatic plan is needed.")
        self.continue_capture = self._button(self.pages[1], "Continue to capture >", lambda: self.tabs.select(2))
        self.continue_capture.pack(anchor="w", pady=10)

    def _capture_page(self):
        outer = self.pages[2]
        self.fixed_capture = self.ttk.Frame(outer)
        self._text(self.fixed_capture, "Eye to hand · manual capture", style="Heading.TLabel").pack(anchor="w")
        self._text(self.fixed_capture, "Keep the camera fixed on the platform and the board rigidly attached "
                   "to the flange. "
                   "Keep the robot in Local Control. Start collection, jog with the pendant, release the jog or "
                   "Freedrive control, wait for settling, then choose Capture view while stationary. "
                   "Collect 10-15 views with different positions and tilts about two axes (at least 30° overall). "
                   "Keep the whole board visible. Choose Finish collection, then solve in Results. "
                   "Capture only reads robot state; it does not take robot control. Stop operation ends capture, "
                   "and does not stop pendant-controlled motion.").pack(anchor="w", pady=12)
        self._button(self.fixed_capture, "Start manual collection", lambda: self.start("collect"), step="fixed_collect",
                     style="Primary.TButton").pack(anchor="w", pady=12)
        self.auto_capture = self.ttk.Frame(outer)
        self.auto_capture.pack(fill="x")
        page = self.auto_capture
        self._text(page, "Automatic capture from your first pose", style="Heading.TLabel").pack(anchor="w")
        self._text(page, "After you start, review and approve each motion plan below. The robot will:").pack(
            anchor="w", pady=12
        )
        self._text(
            page,
            "1. Capture the starting view.\n\n2. Probe 30 mm along three flange axes, returning after each."
            "\n\n3. Visit up to 14 views with different tilts, rolls and distances."
            "\n\n4. Wait for settling, then average five frames at each pose."
            "\n\n5. Ask before an updated plan, then return to the starting pose on success.",
        ).pack(anchor="w")
        self._button(page, "Start automatic collection", lambda: self.start("collect"), step="collect",
                     style="Primary.TButton").pack(anchor="w", pady=20)
        self._text(
            page,
            "On a fault or interruption, a stop is requested; check the robot state. There is no automatic recovery move. "
            "After collection, choose Results to solve the saved session.",
        ).pack(anchor="w")

    def refresh_setup(self):
        fixed = self.settings["calibration_type"].get() == "eye_to_hand"
        self.control_preparation.set(
            "Robot in Local Control for pendant jogging; read-only robot state interfaces enabled"
            if fixed else "Robot in Remote Control; other RTDE control clients disconnected")
        self.check_heading.set("Eye to hand · check the view" if fixed else "Check the view, then inspect the plan")
        if fixed:
            self.motion_settings.grid_remove()
            self.replay_button.pack_forget()
            self.simulate_button.pack_forget()
        else:
            self.motion_settings.grid()
            self.simulate_button.pack(side="left", padx=8)
            self.replay_button.pack(anchor="w", pady=(14, 8), before=self.manual_button)
        self.verify_instructions.set(
            "Eye to hand: keep the camera fixed on the platform and the board attached to the flange. "
            "Stay in Local Control and manually collect 10-15 fresh varied views using the pendant. "
            "Release jog/Freedrive, wait for settling, then Capture view; Finish collection when done."
            if fixed else
            "Keep the camera and board mounts unchanged for the selected setup. "
            "Replaying captures new images at previous poses. For a stronger check, "
            "manually collect 10-15 different views with rotations about two axes. Jog using the pendant, "
            "then choose Capture view while stationary; choose Finish when done.")
        for widget in (self.auto_plan, self.auto_capture):
            widget.pack_forget()
            if not fixed:
                widget.pack(fill="x", **({"before": self.continue_capture} if widget is self.auto_plan else {}))
        for widget in (self.fixed_plan, self.fixed_capture):
            widget.pack_forget()
            if fixed:
                widget.pack(fill="x", pady=12,
                            **({"before": self.continue_capture} if widget is self.fixed_plan else {}))

    def _result_page(self):
        ttk, page = self.ttk, self.pages[3]
        page.columnconfigure(0, weight=1)
        self._text(page, textvariable=self.result_status, style="Heading.TLabel").grid(
            row=0, column=0, sticky="w"
        )
        buttons = ttk.Frame(page)
        buttons.grid(row=1, column=0, sticky="ew", pady=12)
        self._button(buttons, "Calibrate RGB and solve", lambda: self.start("calibrate"), step="calibrate",
                     style="Primary.TButton").pack(side="left", padx=(0, 6))
        self._button(buttons, "Solve session", lambda: self.start("solve"), step="solve").pack(side="left")
        self._button(buttons, "Open calibration...", self.open_result).pack(side="left", padx=6)
        self._button(buttons, "Open session...", self.browse_session).pack(side="left")
        flow_buttons(buttons)
        intrinsic_buttons = ttk.Frame(page)
        intrinsic_buttons.grid(row=8, column=0, sticky="w", pady=4)
        self._button(intrinsic_buttons, "Estimate RGB intrinsics from session", lambda: self.start("intrinsics"),
                     step="intrinsics").pack(side="left")
        self._text(page, "Intrinsic estimates need fresh views across the image for validation. After estimation, "
                   "solve again with the selected camera model. Calibrate RGB and solve performs both offline steps; "
                   "Solve session uses the selected or recorded model.").grid(row=9, column=0, sticky="w", pady=4)
        self._text(page, textvariable=self.result_location).grid(row=2, column=0, sticky="w", pady=4)
        metric_frame = ttk.Frame(page)
        metric_frame.grid(row=3, column=0, sticky="ew", pady=6)
        metric_frame.columnconfigure(0, weight=1)
        self.metrics = ttk.Treeview(metric_frame, columns=("value",), show="tree headings", height=9)
        self.metrics.heading("#0", text="Quality metric")
        self.metrics.heading("value", text="Result")
        self.metrics.column("#0", width=300, minwidth=140)
        self.metrics.column("value", width=150, minwidth=110)
        self.metrics.grid(row=0, column=0, sticky="ew")
        scrollbar = ttk.Scrollbar(metric_frame, command=self.metrics.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.metrics.configure(yscrollcommand=scrollbar.set)
        self._text(page, textvariable=self.warnings, foreground="#8b4c12").grid(
            row=4, column=0, sticky="w", pady=6
        )
        self.pose_heading = self.tk.StringVar(value="Camera in flange · UR pose [m, rad]")
        ttk.Label(page, textvariable=self.pose_heading, style="Heading.TLabel").grid(
            row=5, column=0, sticky="w", pady=(12, 4)
        )
        self._text(page, textvariable=self.pose, font=("Courier", 10)).grid(row=6, column=0, sticky="w")
        exports = ttk.Frame(page)
        exports.grid(row=7, column=0, sticky="ew", pady=12)
        self._button(exports, "Copy UR pose", self.copy_pose).pack(side="left")
        self._button(exports, "Save calibration copy...", self.save_result).pack(side="left", padx=6)
        self._button(exports, "Continue to verify >", lambda: self.tabs.select(4)).pack(side="left")
        flow_buttons(exports)

    def _verify_page(self):
        page = self.pages[4]
        self._text(page, "Verify using fresh observations", style="Heading.TLabel").pack(anchor="w")
        self.verify_instructions = self.tk.StringVar()
        self._text(page, textvariable=self.verify_instructions).pack(anchor="w", pady=12)
        form = self.ttk.Frame(page)
        form.pack(fill="x")
        form.columnconfigure(1, weight=1)
        self._entry(form, 0, "Verification folder", self.verification, self.browse_verification)
        self.replay_button = self._button(page, "Collect fresh views (replay)", lambda: self.start("replay"),
                                          step="replay")
        self.replay_button.pack(anchor="w", pady=(14, 8))
        self.manual_button = self._button(page, "Collect different views (manual)", lambda: self.start("manual"),
                                          step="manual")
        self.manual_button.pack(anchor="w", pady=4)
        self._button(page, "Verify calibration", lambda: self.start("verify"), step="verify",
                     style="Primary.TButton").pack(anchor="w", pady=12)
        self._text(
            page,
            "Default pass limits: maximum board-position error <= 2 mm and rotation error <= 1°. "
            "The CLI offers board refitting if the board was moved.",
        ).pack(anchor="w", pady=6)
        self._text(page, textvariable=self.verify_status, style="Heading.TLabel").pack(
            anchor="w", pady=12
        )

    def values(self):
        return {key: value.get() for key, value in self.settings.items()}

    def hardware_key(self):
        return tuple((k, v) for k, v in self.values().items() if k != "session")

    def browse_manifest(self):
        from tkinter import filedialog

        path = filedialog.askopenfilename(
            parent=self.root, title="Select board manifest", filetypes=[("JSON", "*.json")]
        )
        if path:
            self.settings["manifest"].set(path)

    def browse_intrinsics(self):
        from tkinter import filedialog

        path = filedialog.askopenfilename(parent=self.root, title="Select RGB intrinsic calibration",
                                          filetypes=[("JSON", "*.json")])
        if path:
            self.settings["intrinsics"].set(path)

    def browse_collision_scene(self):
        from tkinter import filedialog
        path = filedialog.askopenfilename(title='Choose a collision scene', filetypes=[('Collision scene', '*.json')])
        if path:
            from .collision import load_scene
            load_scene(path)
            self.settings['collision_scene'].set(path)

    def browse_session(self):
        from tkinter import filedialog

        path = filedialog.askdirectory(
            parent=self.root, title="Choose a new or recorded session folder", mustexist=False
        )
        if path:
            self.settings["session"].set(path)
            self.result_location.set(f"Selected session: {path}")

    def browse_verification(self):
        from tkinter import filedialog

        path = filedialog.askdirectory(parent=self.root, title="Choose verification session folder", mustexist=False)
        if path:
            self.verification.set(path)

    def error(self, message):
        from tkinter import messagebox

        messagebox.showerror("Calibration", str(message), parent=self.root)

    def simulate(self):
        if self.runner.active:
            return
        self.settings["session"].set(session_name("sim"))
        self.tabs.select(3)
        self.start("simulate")

    def start(self, action):
        try:
            if self.runner.active:
                raise ValueError("Wait for the current operation and hardware cleanup to finish")
            downstream = {
                "check": ("plan", "collect"),
                "plan": ("collect",),
                "collect": ("solve", "replay", "manual", "verify"),
                "solve": ("replay", "manual", "verify"),
                "simulate": ("solve", "verify"),
                "replay": ("manual", "verify"),
                "manual": ("replay", "verify"),
                "intrinsics": ("solve", "replay", "manual", "verify"),
                "calibrate": ("intrinsics", "solve", "replay", "manual", "verify"),
            }
            self.reset_steps(action, *downstream.get(action, ()))
            if action in ("plan", "collect", "replay", "manual") and not all(v.get() for v in self.ready):
                raise ValueError("Complete the four preparation checks in Setup before connecting to the robot")
            if action in ("plan", "collect") and self.checked != self.hardware_key():
                raise ValueError("Run Check view successfully with the current settings first")
            if (action == "collect" and self.settings["calibration_type"].get() == "eye_in_hand"
                    and self.planned != self.hardware_key()):
                raise ValueError("Inspect the preliminary plan with the current settings first")
            if action in ("replay", "manual", "verify"):
                if not self.result:
                    raise ValueError("Solve or open a calibration first")
                if self.result["type"] != self.settings["calibration_type"].get():
                    raise ValueError("Loaded calibration differs from the selected mounting setup")
                if self.result["verdict"] == "poor":
                    raise ValueError("This calibration is poor. Review warnings and collect a better session first")
                if action != "verify" and self.is_simulated(self.result):
                    raise ValueError("A simulated calibration cannot be used for live verification collection")
                source = self.result.get("session")
                if action == "verify" and source and Path(source).resolve() == Path(self.verification.get()).resolve():
                    raise ValueError("Verify with fresh observations, separate from the calibration session")
            argv = build_command(
                action, self.values(), calibration=self.result_path, verification=self.verification.get()
            )
            self.job_key = self.hardware_key()
            self.runner.start(argv)
            self.action = action
            self.verification_passed = False
            self.set_step(action, "running")
            if action in ("check", "collect"):
                self.planned = None
            if action in ("collect", "solve", "simulate", "calibrate"):
                self.result = self.result_path = None
                self.result_status.set("Collecting..." if action == "collect" else "Solving...")
                self.result_location.set(f"Session: {self.settings['session'].get()}")
                self.metrics.delete(*self.metrics.get_children())
                self.pose.set("-")
                self.warnings.set("Results will appear when solving completes.")
            self.prompt_frame.grid_remove()
            if action in ("check", "collect", "simulate", "manual", "replay"):
                self.accepted = self.rejected = 0
                self.preview_photo = None
                self.preview_image = None
                self.preview_caption = "Waiting for the first image..."
                for canvas in self.preview_canvases:
                    self._draw_preview(canvas)
                self.sample_status.set("Waiting for the first capture...")
            if action == "verify":
                self.verify_status.set("Verification running...")
            self.status.set(f"Running {action}...")
            self.append_log(f"Starting {action} · {' '.join(argv)}")
            self.set_busy(True)
        except (ValueError, OSError, RuntimeError) as exc:
            if not self.runner.active:
                self.set_step(action, "failed")
            self.error(exc)

    def set_busy(self, busy):
        for widget in self.widgets:
            widget.configure(state="disabled" if busy else "normal")
        self.stop_button.configure(state="normal" if busy and not self.runner.stopping else "disabled")

    def append_log(self, text):
        self.log.configure(state="normal")
        self.log.insert("end", text + "\n")
        if int(self.log.index("end-1c").split(".")[0]) > 800:
            self.log.delete("1.0", "100.0")
        self.log.see("end")
        self.log.configure(state="disabled")

    def show_request(self, event):
        if self.runner.stopping:
            return
        self.status.set(
            "Waiting for your approval" if event["kind"] == "motion" else "Position the robot, then capture"
        )
        self.prompt_text.configure(state="normal")
        self.prompt_text.delete("1.0", "end")
        self.prompt_text.insert("1.0", event["summary"])
        self.prompt_text.configure(state="disabled")
        self.prompt_text.yview_moveto(0)
        for widget in self.prompt_buttons.winfo_children():
            widget.destroy()
        options = (
            (("Approve these moves", True), ("Cancel plan", False))
            if event["kind"] == "motion"
            else (("Capture view", ""), ("Finish collection", "q"))
        )
        for label, value in options:
            self.ttk.Button(
                self.prompt_buttons, text=label, command=lambda v=value, i=event["id"]: self.answer(i, v)
            ).pack(side="left", padx=(0, 8))
        flow_buttons(self.prompt_buttons)
        self.prompt_frame.grid()

    def answer(self, request_id, value):
        try:
            self.runner.answer(request_id, value)
            self.prompt_frame.grid_remove()
            self.status.set(f"Running {self.action}...")
        except (ValueError, OSError) as exc:
            self.error(exc)

    def show_observation(self, event):
        from PIL import Image

        if event.get("image"):
            self.preview_image = Image.open(io.BytesIO(base64.b64decode(event["image"]))).convert("RGB")
            for canvas in self.preview_canvases:
                self._draw_preview(canvas)
        if event["status"] == "ok":
            self.accepted += 1
        else:
            self.rejected += 1
        rmse = event.get("rmse_px")
        detail = f" · RMSE {rmse:.3f} px" if rmse is not None else ""
        reasons = ", ".join(event.get("reasons", []))
        self.sample_status.set(
            f"{event['label']} · {event['status'].upper()}\n{event['corners']} corners{detail}\n"
            f"{self.accepted} accepted · {self.rejected} rejected" + (f"\n{reasons}" if reasons else "")
        )

    @staticmethod
    def is_simulated(result):
        return bool(
            result.get("simulation_truth")
            or result.get("camera", {}).get("simulated")
            or result.get("robot", {}).get("host") == "simulated"
        )

    def show_result(self, result, path):
        from .transforms import describe

        fixed = result["type"] == "eye_to_hand"
        if self.settings["calibration_type"].get() != result["type"]:
            self.settings["calibration_type"].set(result["type"])
        self.result, self.result_path = result, path
        self.pose_heading.set(f"Camera in {'base' if fixed else 'flange'} · UR pose [m, rad]")
        self.reset_steps("replay", "manual", "verify")
        self.set_step("solve", {"good": "ready", "acceptable": "review", "poor": "failed"}[result["verdict"]])
        simulated = self.is_simulated(result)
        self.result_status.set(("SIMULATION · " if simulated else "")
                               + ("EYE TO HAND · " if fixed else "EYE IN HAND · ") + result["verdict"].upper())
        self.result_location.set(str(path))
        m = result.get("metrics", {})
        c, loo = m.get("consistency", {}), m.get("leave_one_out", {})
        rows = [
            ("Usable samples", m.get("sample_count"), ""),
            ("Corner reprojection RMSE", m.get("reprojection_rmse_px"), "px"),
            ("Board consistency / RMS", c.get("position_rms_mm"), "mm"),
            ("Board consistency / position maximum", c.get("position_max_mm"), "mm"),
            ("Board consistency / rotation RMS", c.get("rotation_rms_deg"), "°"),
            ("Board consistency / rotation maximum", c.get("rotation_max_deg"), "°"),
            ("Leave-one-out / RMS", loo.get("position_rms_mm"), "mm"),
            ("Rotation range", m.get("rotation_diversity", {}).get("max_relative_rotation_deg"), "°"),
            ("Rotation axis spread", m.get("rotation_diversity", {}).get("axis_spread"), ""),
        ]
        self.metrics.delete(*self.metrics.get_children())
        estimated = result.get("intrinsics", {}).get("estimation", {})
        model = ("Estimated · needs validation" if estimated and not estimated.get("validated")
                 else result.get("intrinsics_source", {}).get("type", "Recorded"))
        self.metrics.insert("", "end", text="RGB camera model", values=(model,))
        for label, value, unit in rows:
            display = "Unavailable" if value is None else f"{value:.3f} {unit}".strip()
            self.metrics.insert("", "end", text=label, values=(display,))
        uncertainty = m.get("camera_in_base_uncertainty" if fixed else "camera_in_flange_uncertainty", {})
        sigma = uncertainty.get("combined_translation_mm")
        if sigma:
            self.metrics.insert(
                "",
                "end",
                text="Camera translation 1-sigma / X Y Z",
                values=(" / ".join(f"{v:.3f}" for v in sigma) + " mm",),
            )
        camera = describe(result["camera_in_base" if fixed else "camera_in_flange"]["matrix"])
        xyz = camera["xyz_mm"]
        if xyz:
            self.metrics.insert(
                "", "end", text=f"Camera in {'base' if fixed else 'flange'} / X Y Z",
                values=(" / ".join(f"{v:.2f}" for v in xyz) + " mm",)
            )
        board = describe(result["board_in_flange" if fixed else "board_in_base"]["matrix"])
        self.metrics.insert(
            "", "end", text=f"Board in {'flange' if fixed else 'base'} / X Y Z",
                values=(" / ".join(f"{v:.2f}" for v in board["xyz_mm"]) + " mm",)
        )
        self.metrics.insert(
            "",
            "end",
            text=f"Board in {'flange' if fixed else 'base'} / roll pitch yaw",
            values=(" / ".join(f"{v:.2f}" for v in board["rpy_deg"]) + " deg",),
        )
        warnings = list(result.get("warnings", []))
        if simulated:
            warnings.insert(0, "Simulated result - do not use on live hardware.")
        if result["verdict"] == "poor":
            warnings.insert(0, "Calibration failed quality limits. "
                            "Review the camera model and per-view errors before use.")
            if result.get("intrinsics_source", {}).get("type") == "factory":
                warnings.insert(1, "Factory RGB intrinsics are in use. Choose Calibrate RGB and solve to estimate "
                                "lens distortion from the saved session before collecting again.")
        self.warnings.set("\n".join(warnings) or "Quality checks passed. Verify with fresh observations before use.")
        self.pose.set(json.dumps([round(v, 8) for v in camera["pose_ur"]]))
        self.verify_status.set("Collect fresh views without changing the camera or board mounting.")
        self.tabs.select(3)

    def open_result(self):
        from tkinter import filedialog

        path = filedialog.askopenfilename(parent=self.root, title="Open calibration", filetypes=[("JSON", "*.json")])
        if path:
            try:
                self.load_result_path(path)
            except (ValueError, OSError) as exc:
                self.error(exc)

    def load_result_path(self, path):
        path = str(Path(path).expanduser().resolve())
        result = load_result(path)
        if result.get("session"):
            self.settings["session"].set(result["session"])
        self.settings["intrinsics"].set(path)
        self.show_result(result, path)

    def copy_pose(self):
        if self.result:
            self.root.clipboard_clear()
            self.root.clipboard_append(self.pose.get())
            self.status.set("Camera UR pose copied in the displayed reference frame")

    def save_result(self):
        from tkinter import filedialog

        if self.result:
            path = filedialog.asksaveasfilename(
                parent=self.root,
                title="Save calibration copy",
                defaultextension=".json",
                initialfile="calibration.json",
                filetypes=[("JSON", "*.json")],
            )
            if path:
                try:
                    Path(path).write_text(json.dumps(self.result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
                    self.status.set(f"Saved calibration copy to {path}")
                except OSError as exc:
                    self.error(exc)

    def stop(self):
        try:
            self.runner.stop()
        except ProcessLookupError:
            pass
        if self.action and self.runner.active:
            self.set_step(self.action, "stopped")
        self.prompt_frame.grid_remove()
        self.stop_button.configure(state="disabled")
        self.status.set("Capture stop requested · pendant retains robot control" if
                        self.settings["calibration_type"].get() == "eye_to_hand" else
                        "Stop requested · waiting for interruption and hardware cleanup; check the robot state")

    def close(self):
        self.closing = True
        if self.runner.active:
            self.stop()
        else:
            self.root.destroy()

    def callback_error(self, error_type, error, traceback):
        if issubclass(error_type, KeyboardInterrupt):
            self.close()
        else:
            self.stop()
            self.append_log(f"UI action failed; stop requested: {error}")

    def _poll_events(self):
        for event in self.runner.drain():
            kind = event["type"]
            if kind == "log":
                self.append_log(event["message"])
            elif kind == "request":
                self.show_request(event)
            elif kind == "observation":
                self.show_observation(event)
            elif kind == "result":
                self.show_result(event["result"], event["path"])
            elif kind == "intrinsics":
                self.settings["intrinsics"].set(event["path"])
                self.set_step("intrinsics", "review")
                self.warnings.set("\n".join([event["model"]["estimation"]["note"],
                                            *event["model"]["estimation"]["warnings"]]))
                self.result_status.set("RGB intrinsics estimated · solving hand-eye..." if self.action == "calibrate"
                                       else "RGB intrinsics estimated · solve the session again")
                self.result_location.set(event["path"])
                self.tabs.select(3)
            elif kind == "verification":
                report = event["report"]
                self.verification_passed = bool(report["passed"])
                c = report["consistency"]
                self.verify_status.set(
                    f"{'PASS' if report['passed'] else 'FAIL'} · maximum position "
                    f"{c['position_max_mm']:.3f} mm / rotation {c['rotation_max_deg']:.3f}°"
                    + (f"\nLimits: {report['limits']['position_max_mm']:g} mm / "
                       f"{report['limits']['rotation_max_deg']:g}°" if "limits" in report else "")
                    + ("\nFailing views: " + ", ".join(
                        f"{row['label']} ({'/'.join(row['failed_limits'])})" for row in report["failures"])
                       if report.get("failures") else "")
                )
            elif kind == "done":
                code = event["code"]
                state = "ready" if code == 0 else "failed"
                if self.runner.stopping or code == 130:
                    state = "stopped"
                elif code == 0 and self.action in ("solve", "simulate", "calibrate"):
                    state = ({"good": "ready", "acceptable": "review", "poor": "failed"}
                             .get(self.result["verdict"], "failed") if self.result else "failed")
                elif code == 0 and self.action == "verify" and not self.verification_passed:
                    state = "failed"
                elif code == 0 and self.action == "intrinsics":
                    state = "review"
                self.set_step(self.action, state)
                self.set_busy(False)
                self.prompt_frame.grid_remove()
                if code == 0 and self.action in ("check", "plan"):
                    if self.action == "check":
                        self.checked = self.job_key
                    else:
                        self.planned = self.job_key
                elif self.action == "check":
                    self.checked = self.planned = None
                elif self.action == "plan":
                    self.planned = None
                if self.action in ("collect", "solve", "simulate", "calibrate") and not self.result:
                    self.result_status.set("No new calibration · review Activity")
                self.status.set(
                    f"{self.action.capitalize()} {'completed' if code == 0 else 'stopped or failed'} "
                    f"· exit {code} · see Activity for details"
                )
                if code == 0 and self.action == "collect":
                    self.tabs.select(3)
                self.append_log(self.status.get())

    def poll(self):
        try:
            self._poll_events()
        except Exception as exc:
            # A display/decoding error must not leave an active worker running unattended,
            # or prevent later exit events from being processed.
            self.stop()
            self.result = self.result_path = None
            self.result_status.set("Display update failed · review Activity")
            self.append_log(f"UI update failed; stop requested: {exc}")
        if self.closing and not self.runner.active:
            self.root.destroy()
            return
        self.root.after(80, self.poll)


def launch(*, calibration=None):
    try:
        import fcntl
        import tkinter as tk

        from PIL import ImageTk  # noqa: F401 -- check optional system Tk support before opening the window
    except ImportError as exc:
        raise ValueError("Desktop UI needs Tk. On Ubuntu/Debian install python3-tk, then rerun "
                         "./start_calibration_eye_in_robot.sh") from exc
    directory = Path.home() / ".cache" / "ur10e-handeye"
    directory.mkdir(parents=True, exist_ok=True)
    with (directory / "ui.lock").open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise ValueError("The calibration UI is already open for this user") from exc
        try:
            root = tk.Tk()
        except tk.TclError as exc:
            raise ValueError("Desktop UI needs a graphical display. Run ./start_calibration_eye_in_robot.sh "
                             "in your desktop session") from exc
        try:
            app = CalibrationUI(root)
            if calibration:
                app.load_result_path(calibration)
            # SIGTERM is routed through KeyboardInterrupt by the CLI. Keep the event loop alive
            # until the worker has acknowledged interruption and exited its hardware cleanup path.
            while True:
                try:
                    root.mainloop()
                    break
                except KeyboardInterrupt:
                    app.close()
                    if not app.runner.active:
                        break
        except Exception:
            if "app" in locals() and app.runner.active:
                app.close()
                root.mainloop()
            raise
    return 0
