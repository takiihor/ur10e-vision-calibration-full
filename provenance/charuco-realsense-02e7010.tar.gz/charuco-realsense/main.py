#!/usr/bin/env python3
"""Run from a source checkout without installing the package."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))
from charuco_realsense.cli import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main())
