#!/usr/bin/env python3
"""Run from a source checkout without installing the package."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))
from charuco_generator.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
